import React from 'react';
import { Grid, Paper, Avatar, TextField, Button, Typography, Link } from "@material-ui/core";
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

const RegisterUser = () => {

    const paperStyle = { padding: 20, height: '70vh', width: 280, margin: "20px auto" }
    const avatarStyle = { backgroundColor: "#1bbd7e" }
    const btnStyle = {margin: '8px 0'}
    return (
        <Grid>
            <Paper elevation={10} style={paperStyle}>
                <Grid align="center">
                    <Avatar style={avatarStyle}><LockOutlinedIcon /></Avatar>
                    Create an account
                </Grid>
                <TextField
                    label='firstName'
                    placeholder='Enter First Name'
                    fullWidth
                    required>
                </TextField>

                <TextField
                    label='lastName'
                    placeholder='Enter Last Name'
                    fullWidth
                    required>
                </TextField>

                <TextField
                    label='phoneNo'
                    placeholder='Enter Phone No.'
                    fullWidth
                    required>
                </TextField>

                <TextField
                    type="password"
                    label='Password'
                    placeholder='Enter password'
                    fullWidth
                    required>
                </TextField>

                <FormControlLabel
                    control={
                        <Checkbox
                            name="checkedB"
                            color="primary"
                        />
                    }
                    label="Remember me"
                />
                <Button type="submit" color="primary" variant="contained" fullWidth
                style={btnStyle}
                >Sign In</Button>
                <Typography>
                    <Link href="#">
                        Forgot Password?
                    </Link>
                </Typography>
                <Typography > Don't have an account? - 
                    <Link href="#">
                     - Sign Up
                    </Link>
                </Typography>
            </Paper>
        </Grid >
    );
}
export default RegisterUser;