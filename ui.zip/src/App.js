import logo from './logo.svg';
import './App.css';
import ListUsers from './Components/ListUsers';
import Header from './Components/Header';
import Footer from './Components/Footer';
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import CreateUser from './Components/CreateUser';
import ViewUser from './Components/ViewUser';
import Login from './Components/login';
import SignIn from './Components/SignIn';
import {LoginForm} from './Components/LoginForm';
import SignUp from './Components/SignUp';
import UserPage from './Components/UserPage';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Header />
        <div className="container">
          <Switch>
            <Route path="/" exact component={ListUsers}></Route>
            <Route path="/users" component={ListUsers}></Route>
            <Route path="/add-user/:id" component={CreateUser}></Route>
            <Route path="/view-user/:id" component={ViewUser}></Route>
            <Route path="/login" component={Login}></Route>
            <Route path="/sign-in" component={SignIn}></Route>
            <Route path="/loginform" component={LoginForm}></Route>
            <Route path="/signup" component={SignUp}></Route>
            <Route path="/me/:id" component={UserPage}></Route>
           {/*  <Route path="/update-user/:id" component={CreateUser}></Route> */}
          </Switch>
        </div>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
